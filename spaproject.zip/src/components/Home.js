import React from 'react';

const Home = () => {
  return (
    <div className="home-container">
      <h1 className="title">Welcome to My Colorful App</h1>
      <p className="description">This is the homepage of our elegant and colorful React application.</p>
      <div className="cta-button">
        <button className="cta-button">Learn More</button>
      </div>
    </div>
  );
}

export default Home;
