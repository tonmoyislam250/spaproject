import React from 'react';

const About = () => {
  return (
    <div className="about-container">
      <h1 className="title">About Us</h1>
      <p className="description">We are a team of creative developers dedicated to building elegant web applications.</p>
    </div>
  );
}

export default About;
