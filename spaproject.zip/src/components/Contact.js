import React from 'react';

const Contact = () => {
  return (
    <div className="contact-container">
      <h1 className="title">Contact Us</h1>
      <p className="description">Have questions or feedback? Feel free to get in touch with us.</p>
      <div className="contact-info">
        <p>Email: example@example.com</p>
        <p>Phone: (123) 456-7890</p>
      </div>
    </div>
  );
}

export default Contact;
